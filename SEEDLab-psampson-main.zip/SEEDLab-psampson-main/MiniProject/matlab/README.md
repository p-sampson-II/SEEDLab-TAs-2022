# ./matlab

Contains MATLAB code and Simulink block diagrams that were used to identify a first-order transfer function for the Pololu 37D gearmotor used in the project and produce a PI controller suitable for maintaining a desired angular position with that motor.
