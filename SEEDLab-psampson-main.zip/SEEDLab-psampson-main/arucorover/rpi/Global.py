camAngle = 0
status = 2

maxArucoIndex = 9
arucoIndex = 4

cmd = (0,0)

isMarker = False
isCentered = False
isExitBottom = False

