# SEEDLab-psampson
I am working through SEED Lab projects in order to be a good TA for the class. Thus far, I have completed the Mini Project.

## Future Plans

In the next project, I will build a wheeled unit that will use OpenCV and Numpy to seek and identify a fiducial marker used as a waypoint on the ground, move over it, and proceed to the next fiducial marker.
